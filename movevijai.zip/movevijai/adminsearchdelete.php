<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
<body>
<form name="form1" method="post" action="connectdelete.php"> 
Student id : 
<input name="student_id" type="text" id="student_id">
<input type="submit" name="Submit" value="search">
<input type="reset" name="Submit2" value="Reset">
<a href="adminpage.php">Back to adminpage</a>
</form>
</body>
</html>
