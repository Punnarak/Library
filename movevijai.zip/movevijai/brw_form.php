<form action="lnd_save.php" method="post" name="brw_form" target="_self">
<input type="hidden" name="mid" value="<?php echo($mid);?>">
Book ID : <input type="text" name="bid">
<input type="submit" name="submit" value="ENTER">
</form>
