
<?php
session_start();
include("connect.php");
/*
* 1 = Admin
* 2 = User
* 3 = Boss
*/
// variable
$ID    = $_POST['student_id'];


if($ID == '' ){
      echo "check ID or password";
    }

else if(strlen($ID) < 6){
      echo "check ID";
       echo "<meta http-equiv='refresh' content='1;URL=adminsearchdelete.php'>";
}
else {
      $sql = mysql_query("SELECT * FROM student 
                              WHERE student_id = '$ID' ");

      $num = mysql_num_rows($sql);
  if($num <= 0){
echo "check id or password";
             echo "<meta http-equiv='refresh' content='1;URL=adminsearchdelete.php'>";
      } 
       else {

              while ($student = mysql_fetch_array($sql))
              {

                  if($ID == $student['student_id'] )
                  {
                    $_SESSION['student_id']; 
                    $_SESSION['nation_id']; 
                      $_SESSION['name'] ;
                      $_SESSION['password'];
                      $_SESSION['number'];
                      $_SESSION['class'];
                      $_SESSION['room'];     

  echo "<meta http-equiv='refresh' content='1;URL=infodelete.php'>"; 
                  }
                  else
                  {
                        echo "<meta http-equiv='refresh' content='1;URL= adminsearchdelete.php'>"; 
                  }
                 
            }
              }
            }// end else1
?>
 
     
     

