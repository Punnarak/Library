<html>
<head>
	<title>BOOK</title>
      <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
      <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
</head>
<body>
<center>
      <div class="container">
      	<div class="row">
      		<div class="col-md-3"></div>
      			<div class="col-md-6">
                         <h1>BOOK</h1>
      				<form action="checkbook.php" method="post">
      					<div class="form-group">
      						<label for ="code">code</label>
      					<input type="code" class="form-control" 
      					 name ="code"id="code" placeholder="6 code">
      					</div>
      					<br>
      
      					<input type="submit" value="Search" class="btn btn-primary">
      				</form>
      			</div>
      			<div class="col-md-3"></div>
      		</div>
      	</div>
      </center>
 <script type="text/javascript" src="js/jquery.js"></script>
      <script type="text/javascript" src="js.bootstrap.js"></script>
</body>
</html>