<html>
<body>
	<br>
	<center>
    <tr>
	<th>Student ID</th>
	<th>Nation ID</th>
    <th>name</th>
    <th>password</th>
    <th>number</th>
    <th>class</th>
    <th>room</th>
	</tr>
    <tr>
	<th> $_SESSION['student_id']</th>
	<th>$_SESSION['nation_id'];</th>
    <th>$_SESSION['name'];</th>
    <th>$_SESSION['password'];</th>
    <th>$_SESSION['number'];</th>
    <th>$_SESSION['class'];</th>
    <th>$_SESSION['room'];</th>
	</tr>
	
</center>

</body>

</html>
