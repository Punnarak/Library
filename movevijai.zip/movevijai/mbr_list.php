<?php
require("mysql/config.php");
$sql="SELECT student_id, name, class,room FROM student";
if(isset($_GET['kw'])){
	$kw=$_GET['kw'];
	$sql.=" WHERE student_id ='$kw' OR name LIKE '%$kw%' ";
}else{
    $kw="";
    $sql.=" WHERE student_id IS NULL ";
}
require('mysql/connect.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Library System</title>
</head>
<body>
<form action="mbr_list.php" method="get" target="_self">
	Search :
	<input type="text" name="kw" id="kw" value="<?php echo($kw);?>">
<input type="submit" name="submit" value="OK">
</form>
<table border="1" cellspacing="0" cellpadding="2">
	<tr>
		<br>
		<td>ID</td>
		<td>Name</td>
		<td>Class</td>
		<td>ROOM</td>
	</tr>
	<?php while ($record=mysqli_fetch_array($result)){?>
	<tr>
		<td><a href="main.php?student_id=<?php echo($record[0]);?>"><?php echo($record[0]);?></td>
		<td><?php echo($record[1]);?></td>
		<td><?php echo($record[2]);?></td>
		<td><?php echo($record[3]);?></td>
	</tr>
<?php 
} 
require('mysql/unconn.php');
?>
</table>
</body>
</html>