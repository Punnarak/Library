<?php
$sql="SELECT student_id, name, class,room FROM student WHERE student_id = '$mid'";
require('mysql/connect.php');
$record=mysqli_fetch_array($result);
$mid=$record[0];
$mname=$record[1];
$mdep=$record[2];
$R=$record[3];
require('mysql/unconn.php');
?>