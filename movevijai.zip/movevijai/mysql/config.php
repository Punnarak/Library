<?php
$dbuser="root";
$dbpass="12345678";
$dbhost="localhost";
$dbname="logindb";
?>