<?php
mysqli_close($conn);
unset($sql,$result,$record,$conn);
?>