<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
<body>
<form name="form1" method="post" action="connectsadd.php"> 
Student id : 
<input name="student_id" type="text" id="student_id">
<br>
Nation id :
<input name="nation_id" type="text" id="nation_id">
<br>
name : 
<input name="name" type="text" id="name">
<br>
number :
<input name="number" type="text" id="number">
<br>
Class : 
<input name="class" type="text" id="class">
<br>
Room :
<input name="room" type="text" id="room">
<br>
<input type="submit" name="Submit" value="เพิ่มข้อมูล">
<input type="reset" name="Submit2" value="Reset">
</form>
</body>
</html>