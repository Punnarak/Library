<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
<body>
<form name="form1" method="post" action="connecttadd.php"> 
Nation id :
<input name="nation_id" type="text" id="nation_id">
<br>
Name : 
<input name="name" type="text" id="name">
<br>
Department : 
<input name="department" type="text" id="department">
<br>
<input type="submit" name="Submit" value="เพิ่มข้อมูล">
<input type="reset" name="Submit2" value="Reset">
<a href="chooseadd.php">back to chooseadd</a>
</form>
</body>
</html>