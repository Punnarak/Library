<html>
<head>
	<title>user</title>
	<style type='text/css'>
		h1{
			text-shadow: 2px 2px #FFFFFF;
		}

html {
       /* background: url(https://thumbs.gfycat.com/ArcticOblongFlies-size_restricted.gif)
no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover<style*/
</style> 

</head>
<body>

	
</table>
</center>
<br>
<br>
<br>
<br>
<br>
<br>
<a href="library.html"><img src="http://2.bp.blogspot.com/-zpPxbk-19Qk/UHRY0yastLI/AAAAAAAAAT0/nR14IukPKSY/s1600/logout-button-blue-hi.png" width="150"></a>
<a href="manual..html"><img src="http://pngimg.com/uploads/question_mark/question_mark_PNG96.png" width="50" align="right">

</body>
</html>